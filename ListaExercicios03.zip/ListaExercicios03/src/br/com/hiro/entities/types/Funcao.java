package br.com.hiro.entities.types;

public enum Funcao {
	
	Diretor,
	Gerente,
	Desenvolvedor,
	Analista,
	Assistente

}
